package com.wipro.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootAssignment1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
